
В данном файле описана структура, а также очередность запуская файлов для jupyter notebook.

Очередность запуска:

1_clean_data.ipynb

2_eda_deals.ipynb

3_timeseries_analysis.ipynb

4_campaigns_anaysis.ipynb

5_sales_analysis.ipynb

6_paids_&_prods_analysis.ipynb

7_geo_&_lang_analysis.ipynb

8_product_analytics.ipynb

9_dashboard.ipynb

______________________________________________________________________

TanichevaE_Report.pdf - всесторонний отчет о проделанной работе.

TanichevaE_Results_of_Project.pdf - выводы и ркомендации по проекту.

Файл 'City_Coordinates.csv' является служебным и необходим для загрузки геолокации для городов.

_______________________________________________________________________

Очищенные наборы данных:

calls_cleaned.pkl
contacts_cleaned.pkl
deals_cleaned.pkl
spend_cleaned.pkl

metrics.pkl - набор данных с метриками по юнит-экономике. Необходим для дашборда.

